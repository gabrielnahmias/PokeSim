Don't get stuck in the Stone Ages. Go with Markdown (the official "read me" for this project is README.md):

  GitHub:		https://github.com/gabrielnahmias/PokeSim
  Windows:		http://markdownpad.com/
  Mac:		???
  *nix:		???